# Changelog

All notable changes to the BatchTrack ecosystem codebase are documented in this file.

## [Fixed] - 2026-09-26 (Hero Styling & Layout Restoration)

### Fixed
- **Hero & Card Component Styling in `assets/css/common.css`**: Restored all core hero classes (`.hero`, `.hero-copy`, `.hero-visual`, `.stats`, `.stat-box`, `.mini-card`, `.mini-row`, `.product-box`, `.thumb`, `.tag`, `.layout`, `.feature-block`). Previously these classes were omitted from the base CSS, causing the hero grid and visual cards to render as unstyled stacked text.
- **`index.html` Component Restoration**:
  - Restored the interactive demo mini-cards inside `.hero-visual` (Cash recovery card with Colgate Toothpaste batch and Retailer rewards card with live 4% credit and POS-01 station info).
  - Restored the 3-column feature layout blocks (`.layout` / `.feature-block`) introducing Retailer Operating System (Avero), Consumer Intelligence (Trackly), and Unified Ledger (WADN & Change Credits).
  - Restored the clean 3-metric stats row (`1,000+ items per location`, `2 dedicated products`, `99.9% traceability target`).
  - Added favicon link (`favicon.ico`) across all entry points.

## [Fixed] - 2026-09-26 (Runtime Regression Fixes)

### Fixed
- **Supabase 401 Unauthorized**: Corrected the fallback anon key in `assets/js/common.js` and `form.html` to match the valid JWT from `.env` (`{"iss":"supabase","ref":"bwiytslmkiyzdaijjtka", ...}`).
- **404 Resource Errors**: Added static `api/config` JSON file for local static servers and `favicon.ico` on root.
- **`share-modal.js` Analysis**: Confirmed error originates from external Chrome extension `edlifbnjlicfpckhgjhflgkeeibhhcii`.

## [Separated] - 2026-09-26 (Product Separation & Architecture)

### Added
- `trackly.html`: Dedicated consumer intelligence application ("Trackly by BatchTrack")
- `avero.html`: Dedicated retailer operating system ("Avero by BatchTrack")
- `assets/css/common.css`: Shared responsive design tokens and component styling
- `assets/js/common.js`: Shared database adapter wrapper, scanner, and payload utilities
- `Share/BatchTrack-Pro-Ecosystem.zip`: Distribution archive of the refactored workspace

### Changed
- `index.html`: Transformed into the parent BatchTrack Ecosystem gateway
- `vercel.json`: Added clean rewrites for `/trackly` and `/avero` while preserving `/app`, `/form`, and `/survey`
